# Code Citations

## License: unknown
https://github.com/gmhartman/chatbot/tree/23ca685a433fd837061d10f51ce3db3de5075c74/server/index.js

```
(express.static(path.join(__dirname, 'client/build')));
   // app.get('*', (req, res) => {
   //   res.sendFile(path.join(__dirname, 'client/build'
```


## License: unknown
https://github.com/robotlabs/node-react-graphql/tree/e04e6f785c5d17664a3a6edfd820266db84ab09b/app.js

```
.join(__dirname, 'client/build')));
   // app.get('*', (req, res) => {
   //   res.sendFile(path.join(__dirname, 'client/build', 'index.html'
```


## License: unknown
https://github.com/fdmxfarhan/shutter/tree/14ef05ae52096161168cc9483e93fd887a27d26f/app.js

```
')));
   // app.get('*', (req, res) => {
   //   res.sendFile(path.join(__dirname, 'client/build', 'index.html'));
   // });
   /
```

